// test.cc
#include <gcj/cni.h>
#include <java/lang/System.h>
#include <java/io/PrintStream.h>
#include <java/lang/Throwable.h>
#include <gcj/array.h>
#include <java/lang/Double.h>

#include "FastFractal.h"
#include <iostream>

double fastfractal_doubledip( int dim , double* x )
{
	using namespace java::lang;
	
	static Double *jd;
	static String *message;
	static JArray<jdouble> *arrayX;
	static FastFractal *ff;
	static int 	init=0;
	double f=0;
	if (init==0) {
		try
		{
			JvCreateJavaVM(NULL);
			JvAttachCurrentThread(NULL, NULL);
		
			message = JvNewStringLatin1("DoubleDip");
			JvInitClass(&System::class$);
			jd = new Double((jdouble)0);
			
			arrayX = (JArray<jdouble> *) 
				JvNewObjectArray
				(dim, jd->getClass(), NULL);
		
			ff = new FastFractal::FastFractal(message, 3, 1, 1, dim);
		
//			JvDetachCurrentThread();
		}
		catch (Throwable *t)
		{
			System::err->println(JvNewStringLatin1("Unhandled Java exception:"));
			t->printStackTrace();
		}

		init=1;
	}
	for (int i = 0; i < dim; i++)
		elements(arrayX)[i]=(jdouble)x[i];
	jdouble jf = ff->evaluate(arrayX);

	f=jf;//64 bit IEEE floating point number -> C double

	return f;
}
